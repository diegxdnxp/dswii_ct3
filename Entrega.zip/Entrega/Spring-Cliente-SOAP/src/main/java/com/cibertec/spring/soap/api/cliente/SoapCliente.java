package com.cibertec.spring.soap.api.cliente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

@Service
public class SoapCliente {

	@Autowired
	private Jaxb2Marshaller marshaller;

	private WebServiceTemplate template;

/*
	public PostProductoResponse saveProducto(PostProductoRequest request) {
		template = new WebServiceTemplate(marshaller);
		PostProductoResponse data = (PostProductoResponse) template.marshalSendAndReceive("http://localhost:8098/ws",request);
		return data;
	}
*/	
	

	
	
}
