# spring-boot-soap-ws-consumer
How to Consume Soap Webservices using WebServiceTemplate and Spring Boot 
