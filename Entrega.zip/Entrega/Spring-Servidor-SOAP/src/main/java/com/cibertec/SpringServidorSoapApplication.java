package com.cibertec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringServidorSoapApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringServidorSoapApplication.class, args);
	}

}
