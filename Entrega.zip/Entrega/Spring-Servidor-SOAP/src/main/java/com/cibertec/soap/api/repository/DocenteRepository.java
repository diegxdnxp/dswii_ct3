package com.cibertec.soap.api.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cibertec.spring.soap.api.serviciodocente.Docente;


@Repository
public class DocenteRepository {

	 @Autowired
     JdbcTemplate template;


	 
	 public int saveDocente(Docente d){
			String query="insert into tb_docente values(null,?,?,?,?)";
			
		    return template.update(query,d.getNombre(),d.getApellido(),d.getSueldo(), d.getCategoria());
	 }
	 
	 public List<Docente> listDocente(){
		 String sql="select id,nombre,apellido,sueldo,categoria from tb_docente";
		 
	        List<Docente> items = template.query(sql,
	        					(result,rowNum)->new Docente(result.getInt(1),result.getString(2),result.getString(3),
	        							result.getBigDecimal(4), result.getInt(5)));
	        return items;
	 }
	 public int deleteDocente(int cod){
			String query="delete from tb_docente where id=?";
			
		    return template.update(query,cod);
	 }

	 
	 
}



