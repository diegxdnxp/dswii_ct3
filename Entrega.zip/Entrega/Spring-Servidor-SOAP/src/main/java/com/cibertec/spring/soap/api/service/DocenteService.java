package com.cibertec.spring.soap.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cibertec.soap.api.repository.DocenteRepository;
import com.cibertec.spring.soap.api.serviciodocente.DeletePostDocenteResponse;
import com.cibertec.spring.soap.api.serviciodocente.Docente;
import com.cibertec.spring.soap.api.serviciodocente.GetDocenteResponse;
import com.cibertec.spring.soap.api.serviciodocente.PostDocenteResponse;

@Service
public class DocenteService {

	@Autowired
	private DocenteRepository dao;


	public PostDocenteResponse docentePostResponse(Docente docente ) {
		
		PostDocenteResponse data = new PostDocenteResponse();
		int result;
		result = dao.saveDocente(docente);
		data.setSalida(result);
		
		return data;
		
	}
	

	public DeletePostDocenteResponse docenteDeleteResponse(int cod) {
		
		DeletePostDocenteResponse data = new DeletePostDocenteResponse();
		int result;
		result = dao.deleteDocente(cod);
		data.setSalida(result);
		return data;
		
	}
	
	public GetDocenteResponse docenteGetResponse() {
		
		GetDocenteResponse data = new GetDocenteResponse();
		data.setLista(dao.listDocente());
		return data;
		
	}
	
	
}
