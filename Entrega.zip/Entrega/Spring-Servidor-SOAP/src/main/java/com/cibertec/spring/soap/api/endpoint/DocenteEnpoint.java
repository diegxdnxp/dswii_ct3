package com.cibertec.spring.soap.api.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.cibertec.spring.soap.api.service.DocenteService;
import com.cibertec.spring.soap.api.serviciodocente.DeletePostDocenteResponse;
import com.cibertec.spring.soap.api.serviciodocente.DeletePostDocenteResquest;
import com.cibertec.spring.soap.api.serviciodocente.GetDocenteResponse;
import com.cibertec.spring.soap.api.serviciodocente.PostDocenteRequest;
import com.cibertec.spring.soap.api.serviciodocente.PostDocenteResponse;

@Endpoint
public class DocenteEnpoint {

	private static final String NAMESPACE = "http://www.cibertec.com/spring/soap/api/servicioDocente";
	
	@Autowired
	private DocenteService service;

	
	
	@PayloadRoot(namespace =NAMESPACE, localPart = "postDocenteRequest")
	@ResponsePayload
	public PostDocenteResponse postDocenteResponse(@RequestPayload PostDocenteRequest request) {
		
		return service.docentePostResponse(request.getDocente());
		
	}
	
	
	@PayloadRoot(namespace =NAMESPACE, localPart = "deletePostDocenteRequest")
	@ResponsePayload
	public DeletePostDocenteResponse deleteDocenteResponse(@RequestPayload DeletePostDocenteResquest request) {
		
		return service.docenteDeleteResponse(request.getId());
		
		
	}
	
	
	@PayloadRoot(namespace =NAMESPACE, localPart = "getDocenteRequest")
	@ResponsePayload
	public GetDocenteResponse getDocenteResponse() {
		
		return service.docenteGetResponse();
		
		
	}
	
}
