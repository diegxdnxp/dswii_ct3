package com.project.consorcio;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringServidorRestApplicationTests {

	//@Test
	void contextLoads() {
	}

}
